'use strict';
/**
 * 一条下载任务的实际执行：下载 → 手机端适配打包 → 清理缓存。
 * 只做业务，不管队列与状态 —— 队列/并发/持久化在 dlhub.js。
 */
const fs = require('fs');
const path = require('path');
const configMod = require('./config');
const { config } = configMod;
const packer = require('./pack');

/** 取消信号：由调用方在阶段边界检查 */
class CancelledError extends Error {
  constructor(msg = '任务已取消') {
    super(msg);
    this.name = 'CancelledError';
    this.cancelled = true;
  }
}

/** 下载引擎：只剩纯 JS 一条路径（steamjs），保留函数名给 server/dlhub 复用 */
function activeEngine() {
  return 'steamjs';
}

function noLoginMessage() {
  return '还没有登录 Steam：请点右上角 ⚙ 填账号密码登录，或导入 Steam 凭据（node bin/wempkg.js steamjs token 得到的那段 Base64）';
}

/**
 * 整个进程共用一条 Steam 连接。
 * Steam 不允许同一个 refresh token 同时建两条 CM 会话（第二条取 manifest 会 403），
 * 而分块下载本身是并发的，所以多条任务共用一个 client 既安全又不浪费带宽。
 */
let sharedClient = null;
let sharedClientPending = null;

function resetSharedClient() {
  const c = sharedClient;
  sharedClient = null;
  sharedClientPending = null;
  if (c) { try { c.logOff(); } catch { /* ignore */ } }
}

async function getSharedClient(onLog) {
  if (sharedClient) return sharedClient;
  if (!sharedClientPending) {
    const steamjs = require('./steamjs');
    const token = steamjs.readToken();
    if (!token || !token.refreshToken) throw new Error(noLoginMessage());
    sharedClientPending = steamjs.connect(token.refreshToken, { onLog })
      .then((c) => {
        c.on('error', () => { if (sharedClient === c) sharedClient = null; });
        c.on('disconnected', () => { if (sharedClient === c) sharedClient = null; });
        sharedClient = c;
        return c;
      })
      .catch((e) => { sharedClientPending = null; throw e; });
  }
  return sharedClientPending;
}

async function downloadWithEngine(itemId, opts = {}) {
  const onLog = opts.onLog || (() => {});
  const onProgress = opts.onProgress || (() => {});
  // 再兜一层：itemId 会拼成 downloads/js-<id>，非数字可能穿越到下载目录之外
  const safeId = require('./guard').assertItemId(itemId);
  onLog('[engine] steamjs');
  const steamjs = require('./steamjs');
  const cdn = require('./cdn');
  const token = steamjs.readToken();
  if (!token || !token.refreshToken) throw new Error(noLoginMessage());
  const outDir = path.join(config.DOWNLOAD_DIR, `js-${safeId}`);
  const client = await getSharedClient(onLog);
  try {
    const r = await steamjs.downloadItem({ id: safeId, outDir, refreshToken: token.refreshToken, client, onLog, onProgress, isCancelled: opts.isCancelled, isPaused: opts.isPaused });
    return { ok: true, dir: r.dir };
  } catch (e) {
    if (e instanceof CancelledError || e.name === 'CancelledError') throw e;
    // 连接被 Steam 踢掉/过期/超时类故障时，下次重试用新连接
    if (/403|HTTP error|Not Logged On|not logged on|disconnected|timed out|ETIMEDOUT|timeout/i.test(e.message || '')) resetSharedClient();
    throw require('./errors').humanize(e);
  } finally {
    cdn.releaseIdleSockets();
  }
}

/**
 * 删除下载缓存目录，但只在 config.DOWNLOAD_DIR 之内动手：
 * 传进来的目录若是其它地方（比如 Steam 自己的 steamapps），一律不碰。
 */
function purgeDownloadDir(dir, onLog) {
  if (!dir) return null;
  if (config.KEEP_DOWNLOAD) {
    if (onLog) onLog(`下载缓存保留（WE_MPKG_KEEP_DOWNLOAD=1）: ${dir}`);
    return null;
  }
  try {
    const base = path.resolve(config.DOWNLOAD_DIR);
    const abs = path.resolve(dir);
    const rel = path.relative(base, abs);
    if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) return null;
    fs.rmSync(abs, { recursive: true, force: true });
    if (onLog) onLog(`✔ 已清理下载缓存: ${abs}`);
    return abs;
  } catch (e) {
    if (onLog) onLog(`⚠ 清理下载缓存失败: ${e.message}`);
    return null;
  }
}

/**
 * 执行一条任务。
 * @param {{itemId:string,title:string,raw:boolean,reference?:string,preset?:string,
 *          preserveAudio?:boolean,videoMagic?:string}} job
 * @param {{onLog?:Function,onProgress?:Function,isCancelled?:Function}} hooks
 */
async function runJob(job, hooks = {}) {
  const onLog = hooks.onLog || (() => {});
  const onProgress = hooks.onProgress || (() => {});
  const cancelled = () => !!(hooks.isCancelled && hooks.isCancelled());
  const checkpoint = () => { if (cancelled()) throw new CancelledError(); };

  const itemId = String(job.itemId);
  onLog(`开始处理条目 ${itemId}`);

  // 下载阶段：0-100% 由字节数推进（下载器逐文件汇总）
  const dl = await downloadWithEngine(itemId, {
    onLog,
    isCancelled: hooks.isCancelled,
    isPaused: hooks.isPaused,
    onProgress: (p) => {
      onProgress({
        phase: 'download',
        percent: p.totalSizeBytes ? Math.min(99, Math.floor((p.bytesDownloaded / p.totalSizeBytes) * 100)) : null,
        bytes: p.bytesDownloaded,
        total: p.totalSizeBytes,
        currentFile: p.currentFile,
        detail: p.currentFile ? `下载 ${p.currentFile}` : '下载中',
      });
    },
  });
  if (!dl.ok) throw new Error(dl.reason || '下载失败（匿名与账号尝试均未产出文件）');
  checkpoint();

  const dlDir = dl.dir || null;

  // 「下载原始资源」：不产出 mpkg，把原始资源打成 zip（scene 先解包 pkg，web 走离线网页包）
  if (job.raw) {
    onLog('导出模式：下载原始资源（打包 zip）');
    const rawexport = require('./rawexport');
    const res = rawexport.exportRaw(dl.dir, {
      id: itemId,
      title: job.title,
      outDir: config.OUTPUT_DIR,
      onLog,
      onProgress: (p) => onProgress(Object.assign({ phase: p.phase || 'rawexport' }, p)),
    });
    if (cancelled()) {
      try { if (res.outFile) fs.rmSync(res.outFile, { force: true }); } catch { /* ignore */ }
      throw new CancelledError('任务已取消（本次导出的原始资源包已删除）');
    }
    checkpoint();
    onLog('全部完成');
    purgeDownloadDir(dlDir, onLog);
    return { result: res, dlDir: null };
  }

  let reference = job.reference || null;
  if (!reference) {
    const refGuess = path.join(config.ROOT, 'refs', `${itemId}.mpkg`);
    if (fs.existsSync(refGuess)) {
      reference = refGuess;
      onLog(`发现参考 mpkg: ${refGuess}`);
    }
  }
  checkpoint();
  const res = await packer.packFromItemDir(dl.dir, {
    id: itemId,
    title: job.title,
    reference,
    preset: job.preset,
    preserveAudio: job.preserveAudio,
    videoMagic: job.videoMagic,
    onLog,
    onProgress: (p) => onProgress(Object.assign({ phase: p.phase }, p)),
  });
  // 打包中途被「移除」：成品已经落盘了，删掉它，别留下没人认领的 mpkg（缓存保留可续传）
  if (cancelled()) {
    try { if (res.outFile) fs.rmSync(res.outFile, { force: true }); } catch { /* ignore */ }
    throw new CancelledError('任务已取消（本次生成的成品已删除）');
  }
  checkpoint();
  onLog('全部完成');
  purgeDownloadDir(dlDir, onLog);
  return { result: res, dlDir: null };
}

module.exports = {
  CancelledError, activeEngine, noLoginMessage, downloadWithEngine, purgeDownloadDir, runJob,
  getSharedClient, resetSharedClient,
};
